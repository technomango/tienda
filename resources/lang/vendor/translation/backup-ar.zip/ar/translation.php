<?php

return array (
  'add' => '',
  'key' => '',
  'language_added' => '',
  'language_name' => '',
  'languages' => '',
  'locale' => '',
  'search' => '',
);
